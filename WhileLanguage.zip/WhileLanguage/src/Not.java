
public class Not extends Bexp{
	
Bexp b;
	
	Not(Bexp b){
		this.b = b;
	}
	boolean eval(State st)
	{
		
		
		return (!b.eval(st));
		
	}

}
