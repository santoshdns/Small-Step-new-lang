
public class Mul extends Aexp{
	
	Aexp left;// = new Aexp();
	Aexp right ; //= new Aexp();
	
	
	Mul(Aexp left, Aexp right) {
		this.left = left;
		this.right = right;
	}

	
int eval(State st){
		return left.eval(st)*right.eval(st);
	} 

}
