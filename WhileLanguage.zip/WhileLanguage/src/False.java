
public class False extends Bexp{
	boolean b;
    boolean eval(State st){
		return false;
	}

}
