import java.util.Hashtable;
import java.util.Set;

public class State {
	
	Hashtable<Var,Integer> StateHashTable = new Hashtable<Var,Integer>();
	
	void assignstate(Var v, Integer n){
	
		StateHashTable.put(v, n);
		
	}
	
	Integer readstate(Var v)
	{
		return StateHashTable.get(v);
	}
	
	void PrintHashTable()
	{
		Set<Var> keys = StateHashTable.keySet(); 
		for(Var key:keys)
		{
			System.out.print(key.c.toString() +":=" + readstate(key)+ "\t");
		}
	}

}
