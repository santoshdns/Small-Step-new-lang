
public class While extends Cexp{

	Bexp b;
	Cexp c;
	
	While(Bexp b, Cexp c)
	{
		this.b = b;
		this.c = c;
	
	}
	
	@Override
	
	public String toString()
	{
		return String.format("While" + b + " do " + c);
	}
	
	SmallStepReturn eval(SmallStepReturn sm)
	{
		boolean b1 = b.eval(sm.stt);
		
		SmallStepReturn ssr = new SmallStepReturn();
		if(!b1)
		{
	    ssr.command = new Skip();
	    ssr.stt = sm.stt;
	
		return ssr;
	    }
		
		else  // if(b1)
		{
			While w = new While(b,c);
			Cexp cj = new Semicolon(c,w);
			
			ssr.command = cj;
			ssr.stt = sm.stt;
			return ssr;
			
		}
	}
	
	
}
