
public class Or extends Bexp {
	
	Bexp b1;
	Bexp b2;
	
	Or (Bexp b1, Bexp b2)
	{
		this.b1 = b1;
		this.b2 = b2;
	}
	
	boolean eval(State st)
	{
		return (b1.eval(st)|b2.eval(st));
	}

}
