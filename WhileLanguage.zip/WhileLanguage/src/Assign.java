
public class Assign extends Cexp{

Var v;
Aexp e;

Assign (Var v, Aexp e){
	this.v = v;
	this.e = e;
}

@Override 
public String toString()
{
	return String.format(v.toString() + " := " + e.toString());
}

SmallStepReturn eval (SmallStepReturn sm)
{
	int n = e.eval(sm.stt);
	State st_new = new State();
	st_new.assignstate(v, n);
	
	SmallStepReturn ssr = new SmallStepReturn();
	Skip skp = new Skip();
	ssr.command = skp;
	ssr.stt = st_new;
	//System.out.print(ssr.command.toString() + "\t");
	//ssr.stt.PrintHashTable();
	return ssr;
	
}

}
