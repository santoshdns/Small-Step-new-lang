
public class Num extends Aexp{
	
     int n;
	
	Num(int n) {
		this.n = n;
	}
	
	@Override 
	public String toString()
	{
		return String.format(new Integer(n).toString());
	}
	
	int eval(State st){
		return n;
	} 
	
}
	


