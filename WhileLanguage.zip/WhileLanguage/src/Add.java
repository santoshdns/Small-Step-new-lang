
public class Add extends Aexp{

	Aexp left;// = new Aexp();
	Aexp right ; //= new Aexp();
	
	
	Add(Aexp left, Aexp right) {
		this.left = left;
		this.right = right;
	}

	
int eval(State st){
		return left.eval(st) + right.eval(st);
	} 

/*
string typeCheck(){
	string left = left.typeCheck();
	string right = right.typeCheck();
	if(left == right) //good
	else //bad
} */
}



