
public class Sub extends Aexp{
	
	Aexp left;// = new Aexp();
	Aexp right ; //= new Aexp();
	
	
	@Override
	public String toString()
	{
		return String.format(left + " - " + right);
	}
	Sub(Aexp left, Aexp right) {
		this.left = left;
		this.right = right;
	}

	
int eval(State st){
		return left.eval(st)-right.eval(st);
	} 

}
