

public class Var extends Aexp{
	
	Character c;
	
	Var(Character c){
		this.c = c;
	}

	@Override 
	public String toString()
	{
		return String.format(new Character(c).toString());
	}
	
	int eval(State st){
		return st.readstate(this);
	} 
}
