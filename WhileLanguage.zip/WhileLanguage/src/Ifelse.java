
public class Ifelse extends Cexp{
	
	Bexp b;
	Cexp c1;
	Cexp c2;
	
	Ifelse(Bexp b, Cexp c1, Cexp c2)
	{
		this.b = b;
		this.c1 = c1;
		this.c2 = c2;
	}
	
	@Override 
	public String toString()
	{
		return String.format("Ifelse (" + b +")" + "?" + c1 + "\t" + c2 + "\t");
	}
	
	SmallStepReturn eval(SmallStepReturn sm)
	{
		//System.out.print("\t \t" + "IF \t" + b + "\t" + c1.eval(st).command.toString() + "\t" + c2.eval(st).command.toString());
		boolean b1 = b.eval(sm.stt);
		
		if(b1 == true)
		{
		SmallStepReturn ssr = new SmallStepReturn();
		ssr.command = c1;
		ssr.stt = sm.stt;
	//	System.out.println(ssr.command.toString());
	//	ssr.stt.PrintHashTable();
		return ssr;
		}
		
		else
		{
			//State st1 = c2.eval(st);
			SmallStepReturn ssr = new SmallStepReturn();
			ssr.command = c2;
			ssr.stt = sm.stt;
		//	System.out.println(ssr.command.toString());
		//	ssr.stt.PrintHashTable();
			return ssr;
			
			
		}
		
	}
	
	

}
