
public class Semicolon extends Cexp {
	
	Cexp c1;
	Cexp c2;
	
	Semicolon (Cexp c1, Cexp c2)
	{
		this.c1 = c1;
		this.c2 = c2;
	}
	
	@Override 
	public String toString()
	{
		return String.format(c1.toString() + " ; " + c2.toString());
	}
	
	SmallStepReturn eval(SmallStepReturn sm)
	{
		SmallStepReturn ssr = new SmallStepReturn();
		
		if (c1 instanceof Skip)
		{
			ssr.stt = sm.stt;
			ssr.command = c2;
			return ssr;
		}
			
		else
		{
			State st1 = c1.eval(sm).stt;
			Cexp c = c1.eval(sm).command;
			Cexp c3 = new Semicolon(c,c2);
			ssr.command = c3;
			ssr.stt = st1;
			return ssr;
			
		}
		
		
	}

}
