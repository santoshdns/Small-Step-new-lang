
public class Skip extends Cexp{
	
	@Override 
	public String toString()
	{
		return String.format("Skip");
	}
	
	
	SmallStepReturn eval(SmallStepReturn sm){
		SmallStepReturn ssr = new SmallStepReturn();
	/*	ssr.command = new Skip();
		ssr.stt = st;
		System.out.println(ssr.command.toString());
		ssr.stt.PrintHashTable(); */
		ssr = null;
		return ssr;
	}

}
