
public class True extends Bexp {
	
	boolean b;
    boolean eval(State st){
		return true;
	}

}
