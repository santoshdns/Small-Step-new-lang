
public abstract class Cexp {
	
	abstract SmallStepReturn eval(SmallStepReturn sm);
	

}
