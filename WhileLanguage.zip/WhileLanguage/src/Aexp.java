import java.util.Hashtable;

public abstract class Aexp {
	
	abstract int eval (State st);
	
	
	
		
	Aexp(){
			
		}
		
	
	
	
	public static void main(String[] args )
    {
    	    
			
		// Test Cases:
		
		
		
		// I. x:= 10; IfElse (50 < x) ? x:=100  x:=5
		
		Var x = new Var('x');
		Assign xass1 = new Assign(x, new Num(0));
		SmallStepReturn v = xass1.eval(new SmallStepReturn());
		Assign xass2 = new Assign(x, new Num(10));
		SmallStepReturn y = xass2.eval(new SmallStepReturn());
	
		
		Bexp b = new less(new Num(50),x);
		
		
		Cexp c1 = new Assign(x, new Num(100));
		Cexp c2 = new Assign (x, new Num(5));
		
		Ifelse ie = new Ifelse(b, c1, c2);
		
		Cexp AST = new Semicolon(xass2,ie);
	
		System.out.print("<<");
		v.stt.PrintHashTable();
		System.out.print(AST.getClass().getName() + ">>");
		System.out.println("\t" + AST.toString());  
		while (!(AST instanceof Skip))
		{
			SmallStepReturn s = AST.eval(v);
			System.out.print("<<");
			s.stt.PrintHashTable();
			System.out.print(s.command.getClass().getName() + ">>");
			AST = s.command;
			v = s;
			System.out.println("\t" + AST.toString());
			
		}
	
		
		
		
	
		//While loop Test case:
		// z:= 10
		// While z>3 do z:=z-1
		
		System.out.println("\n \n \n");
		
		Var z = new Var('z');
	    Cexp asgnZ = new Assign(z, new Num(10));
	    
	    
	   Bexp b1 = new greater(z, new Num(3));
	   
	   Sub c5 = new Sub(z,new Num(1));
	   
	   Assign asgnZ1 = new Assign(z, c5);
	    
	    Cexp AST1 = new While(b1, asgnZ1);
	    
		Assign zass1 = new Assign(z, new Num(10));
		SmallStepReturn e = zass1.eval(new SmallStepReturn());
	    System.out.print("<<");
		e.stt.PrintHashTable();
		System.out.print(AST1.getClass().getName() + ">>");
		System.out.println("\t" + AST1.toString());
		
		while (!(AST1 instanceof Skip))
		{
			SmallStepReturn s = AST1.eval(e);
			System.out.print("<<");
			s.stt.PrintHashTable();
			System.out.print(s.command.getClass().getName() + ">>");
			AST1 = s.command;
			e = s;
			System.out.println("\t" + AST1.toString());
			
		}
	    	
		
    }
    	    

}
